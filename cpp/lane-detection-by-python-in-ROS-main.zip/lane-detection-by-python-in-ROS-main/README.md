# ros-python-lane detection
这是b站上那个车道线识别的源码，写在ros框架里面的，用的python，没有用到深度，涉及到鱼眼摄像头的去畸变，鸟瞰图转换，感兴趣区域选择等等。
附上实车效果：https://www.bilibili.com/video/BV19J411t7yA
